from serveur import get_template, render, OK, Redirect, pageDynamique, lancerServeur
import csv

# Les messages de la conversation
conversation = []

# La page dynamique qui affiche une conversation
def page_conversation(url, vars):
	""" Retourner la page de la conversation """
	# charger le patron
	template = get_template('troisieme_page.html')
	# définir les variables
	vars['messages'] = conversation
	# appliquer le patron
	html = render(template, vars)
	# retourner la page au navigateur
	return OK(html)

# La page dynamique qui ajoute un message
def nouveau_message(url, vars):
    nom = vars['name']
    prenom=vars['name2']
    email=vars['mail']
    naissance=vars['birth']
    genre=vars['sexe']
    depart=vars['date2']
    retour=vars['date3']
    voyage=vars['voyageselect']
	# l'insérer au début de la conversation
    conversation.append(nom)
    conversation.append(prenom)
    conversation.append(email)
    conversation.append(naissance)
    conversation.append(genre)
    conversation.append(depart)
    conversation.append(retour)
    conversation.append(voyage)
    print(conversation)
    
    # ouverture en écriture (w, première lettre de write) d'un fichier
    with open('donnees.csv', 'w', newline='') as fichier:
        print("fichier ouvert")
        
        # on déclare un objet writer 
        ecrivain = csv.writer(fichier)
        # quelques lignes:
        for element in conversation:
            ecrivain.writerow([element])
        fichier.close()
    return Redirect('confirmation.html')

# Définir les pages dynamiques :
# Le serveur appelera la fonction `page_conversation` 
# lorsqu'il recevra une requête pour la page `/conversation.html`.
pageDynamique('/conversation.html', page_conversation)
# De même il appelera la fonction `nouveau_message`
# lorsqu'il recevra une requête pour la page `/message`.
pageDynamique('/message', nouveau_message)

# Lancer le serveur
lancerServeur()

